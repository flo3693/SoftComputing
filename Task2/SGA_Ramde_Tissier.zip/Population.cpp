#include "Population.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>
using namespace std;

Population::Population()
{
    Chromosome* temp;
    for(int i=0;i<M;i++)
    {
        temp =new Chromosome();
        chromosomes.push_back(temp);
    }
}

Population::~Population()
{
}

void Population::calcF()
{
    double result=0;
    for(int i=0;i<M;i++)
    {
        result+=chromosomes[i]->fitness;
    }
    F=result;
}

void Population::calcProbas(int j)
{
    chromosomes[j]->probability=chromosomes[j]->fitness/F;
}

void Population::calcDistris(int j)
{
    double distri=0;
    for(int i=0;i<=j;i++)
        distri+=chromosomes[i]->probability;
    chromosomes[j]->distribution=distri;
}

Chromosome* Population::choose()
{
    calcF();
    for(int j=0;j<M;j++)
        calcProbas(j);
    for(int j=0;j<M;j++)
        calcDistris(j);
    int i, index=0;
    double r=(double)rand()/(double)RAND_MAX; //random between 0 and 1
    for(i=1;i<M;i++)
    {
        if(chromosomes[i]->distribution>r && chromosomes[i-1]->distribution<r)
        {
            index=i;
            break;
        }
    }
    return chromosomes[index];
}
