#ifndef FITNESSFUN_H
#define FITNESSFUN_H
#include "Chromosome.h"

class FitnessFun
{
    public:
        FitnessFun();
        virtual ~FitnessFun();
        void calculate(Chromosome* input);
};

#endif // FITNESSFUN_H
