#ifndef CHROMOSOME_H
#define CHROMOSOME_H
#define NBBITS 21

class Chromosome
{
    //private:
    public:
        double value;
        int bits[NBBITS];
        int val_dec;
        double fitness;
        double probability;
        double distribution;
        Chromosome();
        virtual ~Chromosome();

        void calculateValue(int bits[]);

};

#endif // CHROMOSOME_H

