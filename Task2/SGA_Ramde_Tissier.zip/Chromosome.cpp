#include "Chromosome.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>
#include <math.h>
using namespace std;

Chromosome::Chromosome()
{
    val_dec=0;
    for(int i=0;i<NBBITS;i++)
        bits[i]=rand()%2;
    calculateValue(bits);
}

Chromosome::~Chromosome()
{

}


void Chromosome::calculateValue(int bits[])
{
    val_dec=0;
    for(int i=0;i<NBBITS;i++)
        val_dec+=pow(2,i)*bits[i];
    value=0.5+((double)((double)val_dec*2.0)/(double)2097151) ;//(2^21)-1=209715
}
