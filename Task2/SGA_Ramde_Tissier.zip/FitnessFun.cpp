#include "FitnessFun.h"
#include <math.h>

FitnessFun::FitnessFun()
{

}

FitnessFun::~FitnessFun()
{

}

void FitnessFun::calculate(Chromosome* input)
{
    input->fitness=((exp(input->value)*sin(10*(input->value)*M_PI)+1)/((input->value)+5));
}

