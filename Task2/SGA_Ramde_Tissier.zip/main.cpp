#include <iostream>
#include <vector>
#include "Population.h"
#include "FitnessFun.h"
#include "Chromosome.h"
#include <time.h>
#include<stdlib.h>
#define N 60
#define PC 0.4
//#define PT 0.4
#define PM 0.2
using namespace std;

int main()
{
    srand(time(NULL));
    int i;
    double mean=0.0;
    int run=0;
    int gen;
    double r;
    double bestSolutions[N];
    FitnessFun* fun=new FitnessFun();
    Population* current=new Population();
    Population* next=new Population();
    next->chromosomes.clear();

    while(run!= N)
    {
        gen=0;

       while(gen!=N)
       {
            for(int j=0;j<M;j++)
            {
                fun->calculate(current->chromosomes[j]);
            }

            i=0;
            while(i<M)
            {
                r=(double)rand()/(double)RAND_MAX;// random number between 0 and 1

                if(r<=PC)
                {
                    //perform crossing
                    int j=rand()%NBBITS;
                    int tempBits[NBBITS-j];
                    Chromosome* temp1=current->choose();
                    Chromosome* temp2=current->choose();
                    for(int k=0;k<NBBITS-j;k++)
                        tempBits[k]=temp1->bits[j+k];
                    for(int k=0;k<NBBITS-j;k++)
                        temp1->bits[j+k]=temp2->bits[j+k];
                    for(int k=0;k<NBBITS-j;k++)
                        temp2->bits[j+k]=tempBits[k];
                    temp1->calculateValue(temp1->bits);
                    temp2->calculateValue(temp2->bits);
                    next->chromosomes.push_back(temp1);
                    next->chromosomes.push_back(temp2);
                    i+=2;
                }
                else if(r>PC && r<=PC+PM)
                {
                    //perform mutation
                    int j=rand()%NBBITS;
                    Chromosome* temp=current->choose();
                    temp->bits[j]=1-(temp->bits[j]); //flip the bit
                    temp->calculateValue(temp->bits);
                    next->chromosomes.push_back(temp);
                    i++;
                }
                else{
                    //perform reproduction
                    Chromosome* temp=current->choose();
                    next->chromosomes.push_back(temp);
                    i++;
                }
            }
            //check if current and temp have the same size, if not delete last element of next
            if(next->chromosomes.size()!=M)
                next->chromosomes.pop_back();

            current->chromosomes.clear();

            for(int k=0;k<M;k++)
                current->chromosomes.push_back(next->chromosomes[k]);

            double biggest=0;
            for(int k=0;k<M;k++)
            {
                if(next->chromosomes[k]->value>biggest)
                    biggest=next->chromosomes[k]->value;
            }
            bestSolutions[gen]=biggest;

            next->chromosomes.clear();
            gen++;
       }
        //choose the best solution e.g. the biggest
        double best=0;
        for(int k=0;k<N;k++)
        {
            if(bestSolutions[k]>best)
                best=bestSolutions[k];
        }
        cout<<"Best solution for iteration "<<run+1<<": "<<best<<endl;
        mean+=best;
        run++;
    }
    mean/=N;
    cout<<endl;
    cout<<"Average: "<<mean<<endl;
    return 0;
}
