#ifndef POPULATION_H
#define POPULATION_H
#include "Chromosome.h"
#include <vector>
#define M 40

using namespace std;

class Population
{
    private:
        double F;

    public:
        vector<Chromosome*> chromosomes;
        Population();
        virtual ~Population();

        void calcF();
        void calcProbas(int j);
        void calcDistris(int j);
        Chromosome* choose();

};

#endif // POPULATION_H
