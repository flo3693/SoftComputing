#include "InputNeuron.h"
#include<stdlib.h>
#include <string>
using namespace std;

InputNeuron::InputNeuron()
{
    weight=1;
}

InputNeuron::~InputNeuron()
{}

double InputNeuron::weightedSum(double input)
{
    return input;
}

